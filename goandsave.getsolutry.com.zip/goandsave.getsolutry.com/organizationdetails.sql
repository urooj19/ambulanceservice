-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 25, 2022 at 08:18 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `organizationdetails`
--

-- --------------------------------------------------------

--
-- Table structure for table `branchdata`
--

CREATE TABLE `branchdata` (
  `idB` int(11) NOT NULL,
  `codeB` varchar(20) NOT NULL,
  `emailB` varchar(20) NOT NULL,
  `phB` int(20) NOT NULL,
  `addressB` varchar(50) NOT NULL,
  `totalAmbB` int(20) NOT NULL,
  `totalDriverB` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `branchdata`
--

INSERT INTO `branchdata` (`idB`, `codeB`, `emailB`, `phB`, `addressB`, `totalAmbB`, `totalDriverB`) VALUES
(3, 'ed-123', 'biba@gmail.com', 8765432, 'north', 2, 0),
(5, 'ED-839', 'edhinorth@gmail.com', 300000000, 'Fb Area North Karachi', 10, 11);

-- --------------------------------------------------------

--
-- Table structure for table `driverregister`
--

CREATE TABLE `driverregister` (
  `idD` int(11) NOT NULL,
  `nameD` varchar(20) NOT NULL,
  `phoneD` int(15) NOT NULL,
  `cnicNoD` int(20) NOT NULL,
  `picD` varchar(50) NOT NULL,
  `cnicD` varchar(80) NOT NULL,
  `selectD` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `driverregister`
--

INSERT INTO `driverregister` (`idD`, `nameD`, `phoneD`, `cnicNoD`, `picD`, `cnicD`, `selectD`) VALUES
(1, 'h', 343, 42101, '', '', 'Ehdi'),
(2, 'urooj', 98, 42, '', '', 'chippp');

-- --------------------------------------------------------

--
-- Table structure for table `organizationdata`
--

CREATE TABLE `organizationdata` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(20) NOT NULL,
  `ph` int(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `totalbranch` int(80) NOT NULL,
  `branchdetail` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `organizationdata`
--

INSERT INTO `organizationdata` (`id`, `name`, `email`, `ph`, `address`, `totalbranch`, `branchdetail`) VALUES
(3, 'habib', 'bibanoushad28@gmail.', 65433445, 'North karachi', 23, 'jjj'),
(4, 'edhi', 'edhi@gmail.com', 300000000, 'xxxxxxxxxxxxx Karachi , Pakistan', 4, 'XXXXXXXXXXXXX\r\nXXXXXXXXXXXXX\r\nXXXXXXXXXXXXX\r\nXXXXXXXXXXXXX\r\nXXXXXXXXXXXXX\r\nXXXXXXXXXXXXX\r\nXXXXXXXXXX');

-- --------------------------------------------------------

--
-- Table structure for table `user1`
--

CREATE TABLE `user1` (
  `uId` int(11) NOT NULL,
  `uName` varchar(11) NOT NULL,
  `uPass` varchar(11) NOT NULL,
  `uStatus` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user1`
--

INSERT INTO `user1` (`uId`, `uName`, `uPass`, `uStatus`) VALUES
(2, 'habiba', '2828', 0),
(3, 'biba', '2828', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branchdata`
--
ALTER TABLE `branchdata`
  ADD PRIMARY KEY (`idB`);

--
-- Indexes for table `driverregister`
--
ALTER TABLE `driverregister`
  ADD PRIMARY KEY (`idD`);

--
-- Indexes for table `organizationdata`
--
ALTER TABLE `organizationdata`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user1`
--
ALTER TABLE `user1`
  ADD PRIMARY KEY (`uId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `branchdata`
--
ALTER TABLE `branchdata`
  MODIFY `idB` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `driverregister`
--
ALTER TABLE `driverregister`
  MODIFY `idD` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `organizationdata`
--
ALTER TABLE `organizationdata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user1`
--
ALTER TABLE `user1`
  MODIFY `uId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
